
var vendoNames = ['VENDO1', 'VENDO2','VENDO3','VENDO4','VENDO5'];
var vendoIP = ['172.16.0.223', '10.0.0.3','10.0.0.4','10.0.0.5','10.0.0.6'];




function VENDO_CLICK(clicked) {
    alert("IP"+clicked); 
}     
//the array
function showVendoButtons() {
	var container = document.querySelector('.containerVendoBtn');
	for (var i = 0; i < vendoNames.length; i++) {
		var btn = document.createElement("button");
		var vname = vendoNames[i];
		btn.value =vendoIP[i];
		btn.id="vendobutton"+i;
		btn.classList.add("btncircle");
		btn.onclick = function() { 
			func_insertCoin(this.value); 
		};
		var t = document.createTextNode(vname);
		btn.appendChild(t);
		container.appendChild(btn);
	}
}

window.onload = function(){
	showVendoButtons();
}