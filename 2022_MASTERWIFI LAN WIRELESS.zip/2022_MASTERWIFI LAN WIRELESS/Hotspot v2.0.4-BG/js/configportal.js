// Portal Version 2.1.1
//set IP and Names
//sample
//var vendoIP = ['10.0.0.2','10.0.0.3','10.0.0.4','10.0.0.5']; 
//var vendoDescription = ['Aldous Vendo','Aurora Vendo','Balmond Vendo','Beatrix Vendo'];

var vendoIP = ['10.0.0.2']; 
var vendoDescription = ['Aldous Vendo'];



var InsertCoinButtonName = "Insert Coin";
//Validity
var Show_Validity = true;
var Validity_Header = "Expiration:";

//Member Login
var Show_Member_Login = true;

var button_Class_Style = "btn-block"; //"btncircle", btn-block" ,"btn-primary"

//message variables

var scrollmessage ="Thank you for using wifi vending machine";

//Login html
var message_Intro = "Insert Coin Now!";
var message_DonePay = "Choose option";
var message_Error = "Contact Admin";

//Status Html
var message_Intro = "Insert Coin Now!"
var message_loading = "Please wait...";


//sound effects
var introduction_dir = "sound/mario1-up.wav"; // put "none" to disable sounds
var coinDrop_dir = "sound/coinsmario.mp3"; // put "none" to disable sounds
var reminder_dir = "sound/insertcoinbg.mp3"; // put "none" to disable sounds
var sucess_dir = "sound/mario1-up.wav"; // put "none" to disable sounds

//auto login mode
// Mode 1 - auto login after done payinh
// Mode 2 - Show option to Login or Copy Voucher
var Mode = 1;

//login mode
// Login Mode 1 - Username only
// Login Mode 2 - Username = password
var LoginMode = 1;

//custom background
//gradient - rainbow animation
//dark - dark mode
var custom_bg = "gradient";

var vendo_connection_timeout = 10000;
var click_insertCoin_timeout = 2000;